import sys, os, json, subprocess, time
sys.path.insert(0, ".")
seq = [("442ca16", "fome12"), ("442ca16", "fome21"), ("58f77af", "fome12"), ("58f77af", "fome21")]
res = []
for tag, c in seq:
    bin_ = "iso/bin/taral_%s" % tag; d = "iso/raw/%s_%s" % (tag, c)
    for f in (d + ".sol", d + ".json"):
        if os.path.exists(f): os.remove(f)
    cmd = [bin_, "corpus/%s.mps" % c, "--method", "dual", "--time-limit", "300", "--sol", d + ".sol", "--json", d + ".json"]
    t = time.perf_counter()
    p = subprocess.Popen(cmd, stdout=open("iso/logs/%s_%s.out" % (tag, c), "w"), stderr=open("iso/logs/%s_%s.err" % (tag, c), "w"))
    try: p.wait(timeout=360)
    except subprocess.TimeoutExpired: p.kill(); p.wait()
    wall = time.perf_counter() - t
    rec = dict(build=tag, case=c, cmd=" ".join(cmd), exit_code=p.returncode, process_wall_s=wall)
    if os.path.exists(d + ".json"):
        j = json.load(open(d + ".json"))
        rec.update({k: j.get(k) for k in ("status", "objective", "iterations", "wall_s", "message")})
        json.dump({k: v for k, v in j.items() if not isinstance(v, list)}, open("iso/logs/%s_%s.slim.json" % (tag, c), "w"))
    else: rec["status"] = "no_json"
    h = json.load(open("raw/highs/%s.json" % c)); rec["highs_status"] = h["status"]; rec["highs_objective"] = h["objective"]
    if rec["status"] == "optimal":
        cp = d + ".check.json"
        r = subprocess.run([sys.executable, "check_one.py", c, d + ".sol", cp], capture_output=True, text=True)
        ck = json.load(open(cp)); rec["checker"] = ck
        rec["rel_obj_err_vs_highs"] = abs(rec["objective"] - h["objective"]) / max(1, abs(h["objective"]))
        rec["match"] = bool(ck["row_violation_rel"] <= 1e-6 and ck["bound_violation"] <= 1e-6 and rec["rel_obj_err_vs_highs"] <= 1e-6
                            and abs(ck["objective"] - rec["objective"]) <= 1e-6 * max(1, abs(rec["objective"])))
    json.dump(rec, open("iso/raw/%s_%s.rec.json" % (tag, c), "w"))
    print(tag, c, rec.get("status"), rec.get("objective"), round(wall, 2), rec.get("iterations"), rec.get("match"), flush=True)
    res.append(rec)
open("iso/done", "w").write("ok")
